var text = "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";
document.write(text.fontsize(5));

var text2 = " Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.";
document.write(text2.bold().fontsize(5).big());

var text3 = " It has survived not only five \ncenturies, but also the leap into electronic typesetting, remaining essentially"; 
document.write(text3.fontsize(5));

var text4 = " UNCHANGED.";
document.write(text4.bold().fontsize(5));

var text5 = "It was popularised in the";
document.write(text5.fontsize(5));

var text6 = "1960";
document.write(text6.bold().fontsize(5));

var text66 = "s";
document.write(text66.small().bold())

var text7 = " with the release of";
document.write(text7.fontsize(5));

var text8 = " LETRASET";
document.write(text8.bold().fontsize(5));

var text9 = " sheets containing Lorem Ipsum passages, ";

var textt = "and more recently with desktop";
document.write(textt.fontsize(5).strike());

var texttt = " publishing \nsoftware like Aldus";
document.write(texttt.fontsize(5))

var text10 = " PageMaker";
document.write(text10.link('https://www.lipsum.com/').fontsize(5));

var text11 = " including versions of";
document.write(text11.fontsize(5));

var text12 = " Lorem Ipsum.";
document.write(text12.big().italics().fontsize(5));
 
 
 

