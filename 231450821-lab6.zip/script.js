function add()
{
  var num1, num2, sum;
  num1 = parseInt(document.getElementById("A").value);
  num2 = parseInt(document.getElementById("B").value);
  sum = num1 + num2;
  document.getElementById("answer").value = sum;
}

function multiply()
{
  var num1, num2, mul;
  num1 = parseInt(document.getElementById("A").value);
  num2 = parseInt(document.getElementById("B").value);
  mul = num1 * num2;
  document.getElementById("answer2").value = mul;
}

function divide()
{
  var num1, num2, div;
  num1 = parseInt(document.getElementById("A").value);
  num2 = parseInt(document.getElementById("B").value);
  div = num1 / num2;
  document.getElementById("answer3").value = div;
}

function subtract()
{
  var num1, num2, mul;
  num1 = parseInt(document.getElementById("A").value);
  num2 = parseInt(document.getElementById("B").value);
  sub = num1 - num2;
  document.getElementById("answer4").value = sub;
}