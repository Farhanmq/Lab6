var clicking = document.getElementById("click");
clicking.addEventListener("click", function () {
  document.getElementById("alert-box").style.display = "block";
});

var ok = document
  .getElementById("ok")
  .addEventListener("click", function () {
    document.getElementById("alert-box").style.display = "none";
  });