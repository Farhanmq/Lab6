function minimum()
{
  var num1, num2, div;
  num1 = parseInt(document.getElementById("a").value);
  num2 = parseInt(document.getElementById("b").value);
  num3 = parseInt(document.getElementById("c").value);
  num4 = parseInt(document.getElementById("d").value);
  num5 = parseInt(document.getElementById("e").value);

  mini = Math.min(num1,num2,num3,num4,num5);
  maxi = Math.max(num1,num2,num3,num4,num5);

  const array1 = [num1,num2,num3,num4,num5];
  const rand = array1[Math.floor(Math.random()*array1.length)];

  document.getElementById("answer").value = mini;
  document.getElementById("answer2").value = maxi;
  document.getElementById("answer3").value = rand;

}